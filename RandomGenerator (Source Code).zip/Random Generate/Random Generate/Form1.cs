﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Random_Generate {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        //Copyright LORENZ FRESH

        List<string> textList = new List<string>();
        int textCounter = 0;

        private void button1_Click(object sender, EventArgs e) {
            // Add string to the list if text in the textbox
            if (textBox1.Text.Length > 0) {
                textList.Add(textBox1.Text); // Add text to the list
                textCounter += 1; // add value for the Text* TextAddet:
                addedCounter.Text = "TextAddet: " + textCounter; // here show the change for the User
                textBox1.Text = ""; // clear the textbox
            }
        }

        private void button2_Click(object sender, EventArgs e) {
            // Reset All Values to nothing
            numMin.Text = "";
            numMax.Text = "";
            textCounter = 0;
            textBox1.Text = "";
            RandomNumber.Text = "= ";
            textList.Clear();
        }

        private void button3_Click(object sender, EventArgs e) {
            // Random Generate
            if (textList.Count > 0) {
                string[] nameList = textList.ToArray();
                Random r = new Random();
                textBox1.Text = nameList[r.Next(0, nameList.Length)];
            }

            if (numMin.Text.Length > 0 && numMax.Text.Length > 0) {
                Random r = new Random();
                int min = Int32.Parse(numMin.Text);
                int max = Int32.Parse(numMax.Text);
                RandomNumber.Text = "= " + r.Next(min, max).ToString();
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e) {

            if (e.KeyCode == Keys.Enter) // if the user press enter
                { 
                // Add string to the list if text in the textbox
                if (textBox1.Text.Length > 0) {
                    textList.Add(textBox1.Text); // Add text to the list
                    textCounter += 1; // add value for the Text* TextAddet:
                    addedCounter.Text = "TextAddet: " + textCounter; // here show the change for the User
                    textBox1.Text = ""; // clear the textbox
                }
            }
        }
    }
}
